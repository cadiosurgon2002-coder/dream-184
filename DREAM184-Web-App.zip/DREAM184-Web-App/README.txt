# DREAM 184 Web App

A mobile-first, offline-first productivity tracker.

## Run locally
Open `index.html` in a modern browser. Daily data is stored in that browser's local storage.

## Install on Android home screen
To get the full PWA install/offline experience, host this folder on an HTTPS static host, then open its URL in Chrome on Android and choose **⋮ > Add to Home screen** or **Install app**.

## Privacy and backups
No account or server is used. Your records stay in this browser on this device. Use **Export backup** regularly. Import the JSON backup if needed.

## Notes
The 184-day calendar starts 19 November 2026. Empty days are left blank in the graph, not counted as zero. Scores are based on the ten habit points (100 total).
